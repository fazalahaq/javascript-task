var products = {
    "Electronics": {
    "Television" : [
    {
    "id" : "PR001",
    "name" : "MAX-001",
    "brand" : "Samsung"
    },
    {
    "id" : "PR002", 
    "name" : "BIG-301",
    "brand" : "Bravia"
    },
    {
    "id" : "PR003", 
    "name" : "APL-02",
    "brand" : "Apple"
    }
    ],
    "Mobile" : [
    {
    "id" : "PR004", 
    "name" : "GT-1980",
    "brand" : "Samsung"
    },
    {
    "id" : "PR005", 
    "name" : "IG-5467",
    "brand" : "Motorola"
    },
    {
    "id" : "PR006", 
    "name" : "IP-8930",
    "brand" : "Apple"
    }
    ]
    },
    "Jewelry" : {
    "Earrings" : [
    {
    "id" : "PR007", 
    "name" : "ER-001",
    "brand" : "Chopard"
    },
    {
    "id" : "PR008", 
    "name" : "ER-002",
    "brand" : "Mikimoto"
    },
    {
    "id" : "PR009", 
    "name" : "ER-003",
    "brand" : "Bvlgari"
    }
    ],
    "Necklaces" : [
    {
    "id" : "PR010", 
    "name" : "NK-001",
    "brand" : "Piaget"
    },
    {
    "id" : "PR011", 
    "name" : "NK-002",
    "brand" : "Graff"
    },
    {
    "id" : "PR012", 
    "name" : "NK-003",
    "brand" : "Tiffany"
    }
    ]
    }
    };
function myfun1(){
var table = "<table border='1'> <tr><th>category</th>  <th>Subcategory</th>  <th>id</th> <th>name</th> <th>Brand</th></tr>";   

    
    for(var i in products)
    {
             //electronics jewelry  
             //loop on object
        for(var j in products[i])
        {
                    //Electronics Television Mobile Jewelry Earrings Necklaces 
                    //loop on objet

            for(var k in products[i][j])
            {        //loop on object of array      
                         //012
                         console.log(k);
                    
                            table += "<tr><td>"+i+"</td> <td>"+j+"</td><td>"+products[i][j][k]['id']+"</td> <td>"+products[i][j][k]['name']+"</td><td>"+products
                            [i][j][k]['brand']+"</td></tr>";   //id name brand
                    
             }
        }

    }
    table += "</table>";
    document.write(table);
}

/////////////////////////////////////////////////////2//////////////////////////////////////////////////////


function myfun2(){
    var table = "<table border='1'> <tr><th>category</th>  <th>Subcategory</th>  <th>id</th> <th>name</th> <th>Brand</th></tr>";

for(var i in products)
    {
        for(var j in products[i])
        {
               if(j == "Mobile"){
               
                   for(var k in products[i][j])
                   {        
                       
                       table += "<tr><td>"+i+"</td> <td>"+j+"</td><td>"+products[i][j][k]['id']+"</td> <td>"+products[i][j][k]['name']+"</td><td>"+products[i][j][k]['brand']+"</td></tr>";
                      }     
             }
        }

    }
    table += "</table>";
    document.write(table);
}
/////////////////////////////////////////////////////3//////////////////////////////////////////////////////////

function myfun3(){
var head = "";
// var table = "<table border='1'> <tr><th>category</th>  <th>Subcategory</th>  <th>id</th> <th>name</th> <th>Brand</th></tr>";    
    for(var i in products)//electronics jewelry   //loop on object
    {
        for(var j in products[i])//Electronics Television Mobile Jewelry Earrings Necklaces //loop on objet
        {
            for(var k in products[i][j])         //loop on object of array//012 //id name brand
            {     
                if(products[i][j][k]["brand"]=="Samsung")
                {
                    head += "<h1>Product Id"+  products[i][j][k]['id']+"</h1> <h1>Product Name"+  products[i][j][k]['name']+"</h1>    <h1>Product Subcategory"+  products[i][j][k]['brand']+"</h1><h1>Product Category"+ i +'</h1>';
                }
             }
        }

    }
    document.write(head);
}
    ////////////////////////////////////////////////4//////////////////////////////////////////////////////
function myfun4(){
    var table = "<table border='1'> <tr><th>category</th>  <th>Subcategory</th>  <th>id</th> <th>name</th> <th>Brand</th></tr>";    
    for(var i in products)//electronics jewelry   //loop on object
    {
        for(var j in products[i])//Electronics Television Mobile Jewelry Earrings Necklaces //loop on objet
        {
            for(var k in products[i][j])         //loop on object of array//012 //id name brand
            {     
                if(products[i][j][k]["id"]=="PR003")
                {
                   products[i][j].splice(k,1);
                }
                else{
                    table += "<tr><td>"+i+"</td> <td>"+j+"</td><td>"+products[i][j][k]['id']+"</td> <td>"+products[i][j][k]['name']+"</td><td>"+products
                            [i][j][k]['brand']+"</td></tr>";
                }
             }
        }

    }
    //document.write(head);
    table += "</table>";
    document.write(table);
}
    /////////////////////////////////////////////5/////////////////////////////////////////////////////////////
    function myfun5(){
    var table = "<table border='1'> <tr><th>category</th>  <th>Subcategory</th>  <th>id</th> <th>name</th> <th>Brand</th></tr>";    
for(var i in products)//electronics jewelry   //loop on object
{
    for(var j in products[i])//Electronics Television Mobile Jewelry Earrings Necklaces //loop on objet
    {
        for(var k in products[i][j])         //loop on object of array//012 //id name brand
        {     
            if(products[i][j][k]["id"]=="PR002")
            {
               products[i][j][k]["name"]="BIG-555";
            }
            
            table += "<tr><td>"+i+"</td> <td>"+j+"</td><td>"+products[i][j][k]['id']+"</td> <td>"+products[i][j][k]['name']+"</td><td>"+products
            [i][j][k]['brand']+"</td></tr>";
         }}}
    //document.write(head);
    table += "</table>";
    document.write(table);
    }


    myfun1();
    myfun2();
    myfun3();
    myfun4();
    myfun5();
